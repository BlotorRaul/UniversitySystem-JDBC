create
    definer = root@localhost procedure numar_max_studenti_materie(IN idProf int, IN materie varchar(30))
begin
    select idMaterie into @idMat from materie where numeMaterie = materie;
    select min(nrParticipantiMax)
    from activitati_materie
    where idMaterie =@idMat and idProfesor = idProf;
end;

