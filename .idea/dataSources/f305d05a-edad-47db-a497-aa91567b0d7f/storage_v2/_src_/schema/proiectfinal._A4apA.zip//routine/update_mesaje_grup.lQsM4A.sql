create
    definer = root@localhost procedure update_mesaje_grup(IN idGrup int, IN mesajNou text)
begin
    update grupstudiu set mesaj = mesajNou where idGrupStudiu = idGrup;
end;

