create
    definer = root@localhost procedure get_prof_activitati_azi_calendar(IN idProf int)
begin
	select m.numeMaterie,c.dataDorita, time(c.dataDorita)
    from calendar c, materie m 
    where c.idProfesor = idProf and m.idMaterie = c.idMaterie and date(c.dataDorita)=curdate();
end;

