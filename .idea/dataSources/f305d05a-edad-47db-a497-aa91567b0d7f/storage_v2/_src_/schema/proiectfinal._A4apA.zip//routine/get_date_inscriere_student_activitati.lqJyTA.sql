create
    definer = root@localhost procedure get_date_inscriere_student_activitati(IN numeMat varchar(30), IN numeProf varchar(30))
begin
    select idMaterie into @idMat from materie where numeMaterie = numeMat;
    
    select p.idProfesor into @idProf
    from profesor p
    join users u
    on u.idUser=p.idUser
    where concat(u.nume,' ',u.prenume) = numeProf;
    
    select s.ziua, s.oraInceput, s.oraSfarsit
    from activitati_materie am, fiecaresaptamana fs, activitate a
    where am.idActivitateMaterie = fs.idActivitateMaterie and a.tipActivitate =am.tipActivitate
    and am.idMaterie = @idMat and am.idProfesor = @idProf
    group by am.idActivitateMaterie
    order by s.ziua, s.oraInceput, s.oraSfarsit;
end;

