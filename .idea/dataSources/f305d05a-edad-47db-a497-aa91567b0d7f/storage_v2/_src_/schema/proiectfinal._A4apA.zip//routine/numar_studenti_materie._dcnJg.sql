create
    definer = root@localhost procedure numar_studenti_materie(IN idProf int, IN materie varchar(30))
begin
	select idMaterie into @idMat from materie where numeMaterie = materie;

    select count(1)
    from note n
    join activitati_materie am
    on am.idActivitateMaterie = n.idActivitateMaterie
    where am.idProfesor = idProf and am.idMAterie = @idMat
    group by am.tipActivitate;
    
end;

