create
    definer = root@localhost procedure profesor_adauga_nota_student(IN idProf int, IN denumireMaterie varchar(30),
                                                                    IN denumireActivitate varchar(30),
                                                                    IN numeStudent varchar(30), IN notaNoua float)
begin
	select s.idStudent into @idStud
    from student s
    join users u
    on u.idUser = s.idUser
    where concat(u.nume, ' ', u.prenume) = numeStudent;
    
    select n.idActivitate into @activitate
    from note n
    join activitati_materie am
    on n.idActivitateMaterie = am.idActivitateMaterie
    join activitate a
    on a.tipActivitate = am.tipActivitate
    join materie m
    on m.idMaterie = am.idMaterie
    join student_materie sm
    on sm.idMaterie = m.idMaterie
    where am.idProfesor = idProf and n.idStudent =@idStud and a.numeActivitate = denumireActivitate and m.numeMaterie = denumireMaterie
    group by(n.idActivitate);
    
    update note
    set nota = notaNoua
    where idStudent =@idStud and idActivitate = @activitate;
end;

