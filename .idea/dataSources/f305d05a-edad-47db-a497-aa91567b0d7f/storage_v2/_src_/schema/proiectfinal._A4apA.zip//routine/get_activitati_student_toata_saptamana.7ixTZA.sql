create
    definer = root@localhost procedure get_activitati_student_toata_saptamana(IN idStud int)
begin
    select a.numeActivitate, m.numeMaterie, fs.ziua, fs.oraInceput, fs.oraSfarsit
    from student_materie sm, materie m, activitati_materie am, activitate a, fiecaresaptamana fs, note n
    where sm.idStudent = idStud and sm.idMaterie = m.idMaterie and m.idMaterie = am.idMaterie and a.tipActivitate = am.tipActivitate and fs.idActivitateMAterie = am.idActivitateMAterie
    and n.idActivitateMaterie = am.idActivitateMaterie;
    
end;

