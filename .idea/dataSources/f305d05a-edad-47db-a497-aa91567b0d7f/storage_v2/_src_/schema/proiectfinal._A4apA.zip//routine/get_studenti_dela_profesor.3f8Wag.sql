create
    definer = root@localhost procedure get_studenti_dela_profesor(IN idProf int)
begin
	 select m.numeMaterie, concat(u.nume+ ' '+ u.prenume) as 'nume', a.numeActivitate, n.nota
     from profesor p
     join profesor_materie pm
     on p.idProfesor = pm.idProfesor
     join materie m
     on m.idMaterie = pm.idMaterie
     join activitati_materie am
     on m.idMaterie = am.idMaterie
     join activitate a
     on a.tipActivitate = am.tipActivitate
     join note n
     on n.idActivitateMaterie = am.idActivitateMaterie
     join student s 
     on s.idStudent = n.idStudent
     join users u
     on u.idUser = s.idUser
     where am.idProfesor = idProf and p.idProfesor = am.idProfesor
     order by m.numeMaterie, concat(u.nume+ ' '+ u.prenume);
     
end;

