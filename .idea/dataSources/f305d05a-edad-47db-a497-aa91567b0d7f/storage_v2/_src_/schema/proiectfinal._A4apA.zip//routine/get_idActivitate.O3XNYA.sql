create
    definer = root@localhost procedure get_idActivitate(IN idStud int, IN idMat int)
begin
	select am.idActivitateMaterie
    from activitati_materie am
    join note n on
    n.idActivitateMaterie = am.idActivitateMaterie
    where n.idStudent =idStud and am.idMaterie =idMat;
end;

