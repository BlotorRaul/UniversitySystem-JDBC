create
    definer = root@localhost procedure populate_activitati_materie(IN denumireMaterie varchar(30),
                                                                   IN denumireActivitate varchar(30), IN pondere int,
                                                                   IN nrMax int, IN idProf int)
begin
	select a.tipActivitate into @param1
    from activitate a
    where a.numeActivitate = denumireActivitate
    group by(a.tipActivitate); #ptr a fi valori distincte ptr fiecare tip de activitate
    
    select m.idMaterie into @param2
    from materie m
    where m.denumire = denumireMaterie
    group by(m.idMaterie);
    
    set @param3 = idProf;
    set @param4= nrMax;
    set @param5 = pondere;
    
    insert into activitati_materie(tipActivitate, idMaterie, idProfesor,nrParticipiantiMax,pondereNota)
    values (@param1, @param2,@param3,@param4,@param5);
    
end;

