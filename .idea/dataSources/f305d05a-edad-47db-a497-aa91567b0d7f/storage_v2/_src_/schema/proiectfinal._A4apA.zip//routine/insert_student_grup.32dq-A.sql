create
    definer = root@localhost procedure insert_student_grup(IN idGrup int, IN idStud int)
begin
    insert into grup_studiu_student values(idGrup,idStud);
end;

