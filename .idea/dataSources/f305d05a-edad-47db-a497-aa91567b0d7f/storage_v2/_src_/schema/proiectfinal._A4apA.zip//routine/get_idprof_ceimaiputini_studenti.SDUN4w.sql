create
    definer = root@localhost procedure get_idprof_ceimaiputini_studenti(IN materie varchar(30))
begin
    select p.idProfesor, count(sm.idStudent)
    from profesor p
    join profesor_materie pm
    on pm.idProfesor = p.idProfesor
    join materie m
    on m.idMaterie = pm.idMaterie
    join student_materie sm
    on sm.idMaterie = m.idMaterie
    where m.numeMaterie = materie and p.idProfesor = sm.idProfesor
    group by p.idProfesor
    order by count(sm.idStudent) ASC;
end;

