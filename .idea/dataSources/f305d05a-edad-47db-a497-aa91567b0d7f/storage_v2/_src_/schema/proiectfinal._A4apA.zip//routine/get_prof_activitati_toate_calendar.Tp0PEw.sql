create
    definer = root@localhost procedure get_prof_activitati_toate_calendar(IN idProf int)
begin
	select m.numeMaterie,c.dataDorita
    from calendar c, materie m 
    where c.idProfesor = idProf and m.idMaterie = c.idMaterie and c.dataDorita>=curdate()
    order by c.dataDorita;
end;

