create
    definer = root@localhost procedure set_nota(IN idStud int, IN idMat int, IN notaNou float)
begin
    update note n
    join  activitati_materie am
    on am.idActivitateMaterie = n.idActivitateMaterie
    set n.nota = notaNou
    where n.idStudent = idStud and am.idMaterie = idMat;
end;

