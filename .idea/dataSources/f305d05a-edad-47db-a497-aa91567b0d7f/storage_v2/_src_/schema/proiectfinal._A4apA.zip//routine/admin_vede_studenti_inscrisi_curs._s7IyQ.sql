create
    definer = root@localhost procedure admin_vede_studenti_inscrisi_curs(IN numeCurs varchar(30))
begin
    select concat(u.nume, ' ', u.prenume)
    from users u, student s, student_materie sm, materie m
    where u.idUser = s.idUser and s.idStudent = sm.idStudent and m.idMaterie= sm.idMaterie
    and u.tipUser ='Student' and m.numeMaterie = numeCurs;
end;

