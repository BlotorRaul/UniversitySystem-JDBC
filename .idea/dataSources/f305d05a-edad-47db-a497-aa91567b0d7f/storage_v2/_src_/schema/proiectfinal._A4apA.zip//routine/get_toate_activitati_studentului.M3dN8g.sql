create
    definer = root@localhost procedure get_toate_activitati_studentului(IN idStud int, IN idGrupa int)
begin
    select agsp.denumire, agsp.dataDesfasurare
    from grup_studiu_student gss 
    join  student_activitati_grup sag
    on gss.idStudent = sap.idStudent
    join activitati_grup_studiu_planificare agsp 
    on sap.idActivitate = agsp.idActivitate
    where gss.idGrupStudiu = idGrupa and gss.idStudent = idStud and agsp.dataDesfasurare > current_timestamp()
    group by sag.idActivitate;
end;

