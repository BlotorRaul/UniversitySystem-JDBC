create
    definer = root@localhost procedure get_media(IN idStud int, IN idMat int)
begin
    select n.nota, am.pondereNota
    from note n
    join activitati_materie am
    on am.idActivitateMaterie = n.idActivitate
    where n.idStudent = idStud and am.idMaterie = idMat;
end;

