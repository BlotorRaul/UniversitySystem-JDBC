create
    definer = root@localhost procedure update_user(IN cnp_ varchar(45), IN adrs text, IN nrTel varchar(45),
                                                   IN mail varchar(45), IN iban_ varchar(45), IN nrC int,
                                                   IN numeUtilizator varchar(45), IN tipU varchar(45))
begin
    UPDATE utilizator SET CNP=cnp_, adresa=adrs, numarTelefon=nrTel, email=mail, IBAN=iban_, nrContract=nrC WHERE concat(nume,' ',prenume)=numeUtilizator AND tipUtilizator=tipU;
end;

