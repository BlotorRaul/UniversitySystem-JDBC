create
    definer = root@localhost procedure insert_fiecaresaptamana(IN idProf int, IN materie varchar(30),
                                                               IN activitate varchar(30), IN zi varchar(30),
                                                               IN inc time, IN sf time)
begin
    set @idMat = (select idMaterie from materie where numeMAterie = materie);
    set @idActi = (select tipActivitate from activitate where numeActivitate = activitate);
    set @rezultat = (select idActivitate from activitate_materie where idMaterie = @idMat and idProfesor = idProf and tipActivitate = @idActi);
    
    insert into fiecaresaptamana values(@rezultat, zi, inc, sf);
end;

