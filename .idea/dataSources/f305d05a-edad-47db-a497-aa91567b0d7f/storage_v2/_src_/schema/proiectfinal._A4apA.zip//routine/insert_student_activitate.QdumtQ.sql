create
    definer = root@localhost procedure insert_student_activitate(IN idStud int, IN idActi int)
begin
    insert into student_activitati_grup values(idActi, idStud);
end;

