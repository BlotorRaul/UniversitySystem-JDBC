create
    definer = root@localhost procedure delete_student_tabel_note(IN idStud int, IN idActi int)
begin
	delete from note where idStudent = idStud and idActivitateMaterie = idActi;
end;

