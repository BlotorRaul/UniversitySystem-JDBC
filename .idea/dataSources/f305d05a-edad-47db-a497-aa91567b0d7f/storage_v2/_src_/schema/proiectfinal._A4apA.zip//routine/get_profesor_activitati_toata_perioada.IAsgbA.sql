create
    definer = root@localhost procedure get_profesor_activitati_toata_perioada(IN idProf int)
begin
	select m.numeMaterie, a.numeActivitate, fs.ziua, fs.oraInceput, fs.oraSfarsit
    from activitate a, fiecaresaptamana fs, activitati_materie am, materie m
    where a.tipActivitate = am.tipActivitate and fs.idActivitateMaterie = am.idActivitateMaterie and am.idMaterie = m.idMaterie
     and am.idProfesor = idProf
     order by fs.oraInceput;
end;

