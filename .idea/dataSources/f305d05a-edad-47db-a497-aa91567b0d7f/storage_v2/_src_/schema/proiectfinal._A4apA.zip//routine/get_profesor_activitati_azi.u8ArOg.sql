create
    definer = root@localhost procedure get_profesor_activitati_azi(IN idProf int)
begin
	set @astazi =(select dayname(current_date()));
    
    select m.numeMaterie, a.numeActivitate, fs.oraInceput, fs.oraSfarsit
    from materie m,activitati_materie am, activitate a, fiecaresaptamana fs
    where m.idMaterie = am.idMaterie and a.tipActivitate =am.tipActivitate and fs.idActivitateMaterie = am.idActivitateMaterie
    and fs.ziua = @astazi and am.idProfesor = idProf
    order by fs.oraInceput;
end;

