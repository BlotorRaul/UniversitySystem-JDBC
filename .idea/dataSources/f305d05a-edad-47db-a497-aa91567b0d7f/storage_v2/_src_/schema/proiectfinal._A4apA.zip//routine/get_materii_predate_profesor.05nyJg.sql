create
    definer = root@localhost procedure get_materii_predate_profesor(IN numeProf varchar(30))
begin
    select p.idProfesor into @idProf
    from profesor p
    join user u
    on p.idUser =u.idUser
    where concat(u.nume + ' ' + u.prenume) = numeProf;
    
    select m.numeMaterie
    from materie m
    where m.idMaterie not in (
    select m.idMaterie
    from materie m
    join profesor_materie pm
    on m.idMaterie = pm.idMaterie
    where pm.idProfesor =@idProf)
    group by(m.numeMaterie);
end;

