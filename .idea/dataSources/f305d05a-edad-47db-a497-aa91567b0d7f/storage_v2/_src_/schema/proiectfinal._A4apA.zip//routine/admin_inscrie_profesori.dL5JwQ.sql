create
    definer = root@localhost procedure admin_inscrie_profesori(IN numeProf varchar(30), IN numeCurs varchar(30))
begin
    select p.idProfesor into @idProf
    from profesor p, users u 
    where p.idUser = u.idUser and concat(u.nume, ' ', u.prenume) = numeProfesor 
    and u.tipUser ='Profesor';
    
    select m.idMaterie into @idMat
    from materie m
    where m.numeMaterie = numeCurs;
    
    insert into profesor_materie(idProfesor, idMaterie) values (@idProf, @idMat);
end;

