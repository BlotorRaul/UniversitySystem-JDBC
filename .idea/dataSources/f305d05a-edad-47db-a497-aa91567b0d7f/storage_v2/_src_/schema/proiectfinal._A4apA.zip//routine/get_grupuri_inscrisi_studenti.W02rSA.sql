create
    definer = root@localhost procedure get_grupuri_inscrisi_studenti(IN idStud int)
begin
	select gs.idGrupStudiu,gs.denumireMAterie
    from grupstudiu gs
    join grup_studiu_student gss
    on gs.idGrupStudiu = gss.idGrupStudiu
    where gss.idStudent = idStud;
     
end;

