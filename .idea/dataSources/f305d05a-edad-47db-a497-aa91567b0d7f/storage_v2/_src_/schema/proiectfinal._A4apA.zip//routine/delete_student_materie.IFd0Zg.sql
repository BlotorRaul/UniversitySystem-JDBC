create
    definer = root@localhost procedure delete_student_materie(IN idStud int, IN idMat int)
begin
	#sters din tabela student_materie
	delete from student_materie  where idStudent = idStud and idMaterie=idMat;
end;

