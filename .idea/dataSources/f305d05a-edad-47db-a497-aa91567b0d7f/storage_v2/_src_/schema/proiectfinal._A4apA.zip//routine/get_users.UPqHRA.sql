create
    definer = root@localhost procedure get_users()
begin
	select * from users;
end;

