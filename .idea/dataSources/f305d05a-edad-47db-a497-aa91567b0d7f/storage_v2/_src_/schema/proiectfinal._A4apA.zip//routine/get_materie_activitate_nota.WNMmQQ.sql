create
    definer = root@localhost procedure get_materie_activitate_nota(IN idStud int)
begin
	select m.numeMaterie, a.numeActivitate,n.nota
    from student_materie sm,materie m, activitati_materie am, activitate a, note n
    where sm.idStudent = idStud and sm.idMaterie=m.idMaterie and m.idMaterie =am.idMaterie and am.tipActivitate = a.tipActivitate 
    and n.idActivitateMaterie = am.idActivitateMaterie and n.idStudent = idStud;
    
end;

