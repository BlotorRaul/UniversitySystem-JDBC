create
    definer = root@localhost procedure get_profesor_preda_materie(IN materie varchar(30))
begin
    select idMaterie into @idMat from materie where numeMaterie = materie;
    select concat(u.nume,' ', u.prenume)
    from profesor p
    join users u
    on p.idUser = u.idUser
    join profesor_materie pm
    on pm.idProfesor = p.idProfesor
    where pm.idMaterie = @idMat;
end;

