create
    definer = root@localhost procedure get_idactivitate_profesor_materie(IN idProf int, IN idMat int)
begin
    select idActivitate
    from activitati_materie
    where idMaterie = idMat and idProfesor = idProf;
end;

