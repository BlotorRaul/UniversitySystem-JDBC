create
    definer = root@localhost procedure get_mesaje_grup(IN idGrup int)
begin
    select mesaj
    from grupstudiu
    where idGrupStudiu = idGrup;
end;

