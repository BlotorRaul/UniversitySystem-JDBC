create
    definer = root@localhost procedure get_materie(IN idStud int)
begin
select m.numeMaterie
from student_materie sm
join materie m on
sm.idStudent = m.idMaterie 
where sm.idStudent = idStud;
end;

