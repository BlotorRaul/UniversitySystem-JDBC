create
    definer = root@localhost procedure get_profesor_activitati_bymaterie(IN idMat int)
begin
    select am.idProfesor, concat(u.nume,' ', u.prenume), a.numeActivitate
    from activitati_materie am 
    join profesor p
    on am.idProfesor = p.idProfesor
    join users u
    on u.idUser = p.idUser
    join activitate a
    on a.tipActivitate = am.tipACtivitate
    where am.idMaterie = idMat
    group by am.idProfesor, a.tipActivitate;
end;

