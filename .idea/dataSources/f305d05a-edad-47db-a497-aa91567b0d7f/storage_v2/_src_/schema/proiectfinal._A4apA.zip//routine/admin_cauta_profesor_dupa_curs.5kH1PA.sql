create
    definer = root@localhost procedure admin_cauta_profesor_dupa_curs(IN numeCurs varchar(30))
begin
    select concat(u.nume, ' ', u.prenume)
    from users u, profesor p, profesor_materie pm, materie m
    where u.idUser = p.idUser and p.idProfesor = pm.idProfesor and pm.idMaterie = m.idMaterie and
    m.numeMaterie= numeCurs and u.tipUser = 'Profesor';
end;

