create
    definer = root@localhost procedure verificare_intervale_suprapuse(IN z1 varchar(45), IN o1 time, IN o2 time,
                                                                      IN z2 varchar(45), IN a1 time, IN a2 time)
begin
    select if(z1=z2 and ( (o1<a1 and a1<o2) or(o1<a2 and a2<o2) or (o1=a1 and a2=o2) ),false,true);
end;

