create
    definer = root@localhost procedure get_activitati_grup_valide(IN idGrup int)
begin
    select ag.denumire, ag.dataDesfasurare
    from activitati_grup_studiu_planificare ag
    where ag.idGrupStudiu = idGrup and ag.dataDesfasurare> CURRENT_DATE();
end;

