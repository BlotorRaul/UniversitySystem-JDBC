create
    definer = root@localhost procedure get_membrii_unui_grup(IN idGrup int)
begin
    select gss.idStudent, concat(u.nume+ ' ' + u.prenume)
	from grup_studiu_student gss 
    join student s 
    on s.idStudent = gss.idStudent
    join users u 
    on u.idUser = s.idUser
    where gss.idGrupStudiu = idGrup;
end;

