create
    definer = root@localhost procedure inscriere_student_activitate(IN idGrup int, IN activitate varchar(30))
begin
    select count(gss.idStudent)
    from grup_studiu_student gss, grupstudiu gs, activitati_grup_studiu_planificare agsp
    where gss.idGrupStudiu = gs.idGrupStudiu and gs.idGrupStudiu=agsp.idGrupStudiu and
    gss.idGrupStudiu = idGrup and agsp.denumire = activitate;
end;

