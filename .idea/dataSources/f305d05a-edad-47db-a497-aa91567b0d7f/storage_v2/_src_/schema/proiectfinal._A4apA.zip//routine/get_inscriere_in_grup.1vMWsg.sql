create
    definer = root@localhost procedure get_inscriere_in_grup(IN idStud int)
begin
	select gs.idGrupStudiu, gs.denumireMaterie
    from student s 
    join student_materie sm
	on s.idStudent = sm.idStudent
    join materie m 
    on m.idMaterie = sm.idMaterie
    join grupstudiu gs
    on gs.denumireMaterie = m.numeMaterie
    where s.idStudent = idStud and gs.idGrupStudiu not in (
    select gs.idGrupStudiu
    from grupstudiu gs
    join grup_studiu_student gss
    on gs.idGrupStudiu = gss.idGrupStudiu
    where gss.idStudent = idStud
    );
    
     
end;

