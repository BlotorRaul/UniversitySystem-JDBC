create
    definer = root@localhost procedure get_materii_neinscrise_student_(IN idStud int)
begin
    select count(*) into @ok
    from student_materie
    where idStudent=idStud;
    
    if @ok = 0 then
		select numeMaterie
		from materie
        group by(denumire);
	else
		select m.numeMaterie
        from student_materie sm, materie m
        where sm.idStudent = idStud and m.idMateire not in(
		select m.idMaterie
        from materie m, student_materie sm
        where m.idMaterie = sm.idMAterie and sm.idStudent = idStud
        group by (m.idMaterie)
        )
        group by(m.numeMaterie);
    end if;
end;

