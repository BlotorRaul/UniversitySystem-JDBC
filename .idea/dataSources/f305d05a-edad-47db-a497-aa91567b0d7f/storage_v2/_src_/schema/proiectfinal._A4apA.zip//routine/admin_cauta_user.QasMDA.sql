create
    definer = root@localhost procedure admin_cauta_user(IN numeUtilizator varchar(30), IN tipUtilizator varchar(30))
begin
    select concat(nume,' ',prenume),numarTelefon,CNP,IBAN,adresa,email,nrContract
    from users
    where username = numeUtilizator and tipUser = tipUtilizator;
end;

