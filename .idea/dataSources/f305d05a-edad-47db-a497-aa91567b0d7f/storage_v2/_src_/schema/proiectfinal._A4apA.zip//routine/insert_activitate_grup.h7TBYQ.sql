create
    definer = root@localhost procedure insert_activitate_grup(IN numeActi varchar(30), IN idGrup int,
                                                              IN nrMinPartic int, IN dataDesf datetime,
                                                              IN durataActi time, IN idStud int,
                                                              IN numeProf varchar(30))
begin
    select p.idProfesor into @idProf
    from utilizator u
    join profesor p
    on p.idUser = u.idUser
    where concat(u.nume +' '+ u.prenume) = numeProf;
    
    insert into activitati_grup_studiu_planificare(denumire,idGrupStudiu,idProfesor,numarMinimParticipanti,dataDesfasurare,durata)
    values (numeActi,idGrup,@idProf,nrMinPartic,dataDesf,durataActi);
    
    select activitati_grup_studiu_planificare.idActivitate into @idActi
    from activitati_grup_studiu_planificare
    where denumire = numeActi and idGrupStudiu = idGrup and numarMinimParticipanti = nrMinPartic and dataDesfasurare = dataDesf and durata = durataActi;
    
    insert into student_activitati_grup(idActivitate,idStudent) values (@idActiv,idStud);
    
end;

